package Locked;


import java.rmi.server.Operation;
import java.util.Scanner;

public class Locker_File_Selection {

	public static void main(String []args ) {
		int ch = 0, choice = 0;
		Scanner scr = new Scanner(System.in);
		
		System.out.println("\t Welcome");
		System.out.println("\t Developer\t : Tejas Patel");
		System.out.println("\t Company\t : Company Lockers Pvt Ltd\n");
		
		while(true)
		{
		System.out.println("Select Options : ");
		System.out.println("1. List Files");
		System.out.println("2. Business Level Operations");
		System.out.println("3. Close Application");
		try {
			ch = scr.nextInt();
		}
		catch(Exception e)
		{
			System.out.println("Null Exception Occured");
		}
		
		switch(ch)
		{
		
		case 1: //List function feature to list all files in ascending order.
			Operations.listFiles();
			break;
			
		case 2:
			System.out.println("Please choose one of the following options :");
			System.out.println("1. Add a File");
			System.out.println("2. Delete a File");
			System.out.println("3. Search for a File");
			try 
			{
				choice = scr.nextInt();
			}
			catch (Exception e)
			{
				System.out.println("Null Exception Ocuured");
			}
			switch(choice)
			{
			case 1: 
			
				System.out.println("Enter file name that should be create");
				String filecreate = scr.next();
				Operations.createFile(filecreate);
				break;
			case 2:
			// For Delete a file
				System.out.println("Enter the file that should be delete");
				String filedelete = scr.next();
			// Calling the function for delete a file
				Operations.deleteFile(filedelete);
				break;
			case 3:
			// For  Searching a file
				System.out.println("Enter the file that should be Search");
				String filesearch = scr.next();
			// Calling the function for searching a file
				Operations.searchFile(filesearch);
				break;
				
			default :
				System.out.println("Select valid input");
				break;
			}
			break;
		case 3: // Close the Application
			scr.close();
			System.out.println("Thanks for Using the App...");
			System.exit(0);
			break;
			
		default:
		System.out.println("Invalid input, Select option between 1-3");
		
			}
		}
	
	}
}
	

